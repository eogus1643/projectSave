package com.study_project.web.user.model;

public class User {
	private Integer idx;
	private String name;
	private String gender;
	private String sign_out_date;
	private String sign_out;
	private String mail;
	private String sign_date;
	private String id;
	private String password;
	private String birth;
	private String phone;

	@Override
	public String toString() {
		return "User [idx=" + idx + ", name=" + name + ", gender=" + gender
				+ ", sign_out_date=" + sign_out_date + ", sign_out=" + sign_out
				+ ", mail=" + mail + ", sign_date=" + sign_date + ", id=" + id
				+ ", password=" + password + ", birth=" + birth + ", phone="
				+ phone + "]";
	}
	
	public Integer getIdx() {
		return idx;
	}
	public void setIdx(Integer idx) {
		this.idx = idx;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getSign_out_date() {
		return sign_out_date;
	}
	public void setSign_out_date(String sign_out_date) {
		this.sign_out_date = sign_out_date;
	}
	public String getSign_out() {
		return sign_out;
	}
	public void setSign_out(String sign_out) {
		this.sign_out = sign_out;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getSign_date() {
		return sign_date;
	}
	public void setSign_date(String sign_date) {
		this.sign_date = sign_date;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
}
