package com.study_project.web.email;

public class Email {
	private String title;
	private String ceontent;
	private String receiver;
	
	//getter
	public String getTitle() 	{return title;}
	public String getCeontent() {return ceontent;}
	public String getReceiver() {return receiver;}
	
	//setter
	public void setTitle(String title) {this.title = title;}
	public void setCeontent(String ceontent) {this.ceontent = ceontent;}
	public void setReceiver(String receiver) {this.receiver = receiver;}
	
}
